%declare all variables in mat file 

m=2.5;
k_drag=30;
r=0.15;