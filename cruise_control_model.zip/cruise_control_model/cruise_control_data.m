%cruise control data 

clc
clear all

%mass of the system 
m= 1000;

%damping coefficient 
b=50;

%force between road and the tyre 
u=500;

%implementing PI controller 
Kp=800;
Ki=40;

